import React from 'react';
import './App.css';
import StudentList from './studentList';

function App() {
  return (
    <>
      <StudentList/>
    </>
  );
}

export default App;