import React from 'react';
const Error=()=>{
    return(
      <div>
        <p>Error</p>
      </div>
    );
  };
export default Error;